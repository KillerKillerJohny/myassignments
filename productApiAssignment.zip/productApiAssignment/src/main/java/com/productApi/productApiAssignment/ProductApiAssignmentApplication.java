package com.productApi.productApiAssignment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProductApiAssignmentApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProductApiAssignmentApplication.class, args);
	}

}
